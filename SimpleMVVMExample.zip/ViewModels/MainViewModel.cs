﻿using SimpleMVVMExample.Common;
using SimpleMVVMExample.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Xml.Linq;

namespace SimpleMVVMExample.ViewModels
{
    public class MainViewModel : BaseViewModel
    {
        public MainViewModel() {
            _currentBook = new Book();
            Books = new ObservableCollection<Book>();

            InitializeBooks();
            NextBook = new RelayCommand(OnNextBookEvent, CanMoveNext);
            PreviousBook = new RelayCommand(OnPrevBookEvent, CanMovePrev);            
        }

        private bool CanMovePrev()
        {
            var index = Books.ToList().FindIndex(x => x == CurrentBook);

            return index > 0;
        }

        private bool CanMoveNext()
        {
            var index = Books.ToList().FindIndex(x => x == CurrentBook);

            return index < (Books.Count - 1);
        }

        private void OnPrevBookEvent(object obj)
        {
            var index = Books.ToList().FindIndex(x => x == CurrentBook);

            if (index > 0)
            {
                CurrentBook = Books[index - 1];
            }
        }

        private void OnNextBookEvent(object obj)
        {
            var index = Books.ToList().FindIndex(x => x == CurrentBook);
            
            if (index < (Books.Count - 1))
            {
                CurrentBook = Books[index+1];
            }
        }

        private void InitializeBooks()
        {
            Books = new ObservableCollection<Book>()
            {
                new Book() {Id=1, Name="The Godfather", Author = "Mario Puzo", Price=400.0},
                new Book() {Id=2, Name="The Memory of an Elephant", Author = "Lasker Alex", Price=1500.0},
                new Book() {Id=3, Name="Rich Dad Poor Dad", Author = "Robert Kiyosaki", Price=350.0},
                new Book() {Id=4, Name="The Alchemist", Author = "Paulo Coelho", Price=250.0},
            };

            CurrentBook = Books[0];
        }

        public Book CurrentBook { 
            get { return _currentBook; }
            set { _currentBook = value; OnPropertyChanged("CurrentBook");}
        }

        public ObservableCollection<Book> Books { get; set; }

        Book _currentBook;
        public ICommand NextBook { get; }
        public ICommand PreviousBook { get; }
    }
}
