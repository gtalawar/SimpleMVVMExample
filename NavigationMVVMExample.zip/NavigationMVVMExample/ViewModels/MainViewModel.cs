﻿using SimpleMVVMExample.Common;
using SimpleMVVMExample.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Xml.Linq;

namespace SimpleMVVMExample.ViewModels
{
    public class MainViewModel : BaseViewModel
    {
        private BaseBookViewModel _currentModel;

        public MainViewModel() {
            BookViewModel = new BookViewModel();
            BookListViewModel = new BookListViewModel();

            _currentModel = BookViewModel;

            ShowBookCommand = new RelayCommand(OnShowBookCommandEvent, CanExecuteShowBook);
            ShowBookListCommand = new RelayCommand(OnShowBookListCommandEvent, CanExecuteShowBookList);
        }

        private bool CanExecuteShowBookList()
        {
            return !(_currentModel is BookListViewModel);
        }

        private bool CanExecuteShowBook()
        {
            return !(_currentModel is BookViewModel);
        }

        private void OnShowBookListCommandEvent(object obj)
        {
            CurrentView = BookListViewModel;
        }

        private void OnShowBookCommandEvent(object obj)
        {
            CurrentView = BookViewModel;
        }

        public BaseBookViewModel CurrentView
        {
            get { return _currentModel; }
            set
            {
                _currentModel = value;
                OnPropertyChanged(nameof(CurrentView));
            }
        }
    
        public ICommand ShowBookCommand { get; }
        public ICommand ShowBookListCommand { get; }

        public BookViewModel BookViewModel { get; }
        public BookListViewModel BookListViewModel { get; }
    }
}
