﻿using SimpleMVVMExample.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace SimpleMVVMExample.ViewModels
{
    public class BookViewModel : BaseBookViewModel
    {
        public BookViewModel() {
            NextBook = new RelayCommand(OnNextBookEvent, CanMoveNext);
            PreviousBook = new RelayCommand(OnPrevBookEvent, CanMovePrev);
        }
        private bool CanMovePrev()
        {
            var index = Books.ToList().FindIndex(x => x == CurrentBook);

            return index > 0;
        }

        private bool CanMoveNext()
        {
            var index = Books.ToList().FindIndex(x => x == CurrentBook);

            return index < (Books.Count - 1);
        }

        private void OnPrevBookEvent(object obj)
        {
            var index = Books.ToList().FindIndex(x => x == CurrentBook);

            if (index > 0)
            {
                CurrentBook = Books[index - 1];
            }
        }

        private void OnNextBookEvent(object obj)
        {
            var index = Books.ToList().FindIndex(x => x == CurrentBook);

            if (index < (Books.Count - 1))
            {
                CurrentBook = Books[index + 1];
            }
        }


        public ICommand NextBook { get; }
        public ICommand PreviousBook { get; }
    }
}
