﻿using SimpleMVVMExample.Common;
using SimpleMVVMExample.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace SimpleMVVMExample.ViewModels
{
    public abstract class BaseBookViewModel : BaseViewModel
    {
        public BaseBookViewModel()
        {
            _currentBook = new Book();
            Books = new ObservableCollection<Book>();

            InitializeBooks();
        }

        private void InitializeBooks()
        {
            Books = new ObservableCollection<Book>()
            {
                new Book() {Id=1, Name="The Godfather", Author = "Mario Puzo", Price=400.0},
                new Book() {Id=2, Name="The Memory of an Elephant", Author = "Lasker Alex", Price=1500.0},
                new Book() {Id=3, Name="Rich Dad Poor Dad", Author = "Robert Kiyosaki", Price=350.0},
                new Book() {Id=4, Name="The Alchemist", Author = "Paulo Coelho", Price=250.0},
            };

            CurrentBook = Books[0];
        }

        public Book CurrentBook
        {
            get { return _currentBook; }
            set { _currentBook = value; OnPropertyChanged("CurrentBook"); }
        }

        public ObservableCollection<Book> Books { get; set; }

        Book _currentBook;
    }
}
