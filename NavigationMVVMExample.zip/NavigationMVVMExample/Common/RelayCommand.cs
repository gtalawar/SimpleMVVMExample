﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace SimpleMVVMExample.Common
{
    public class RelayCommand : ICommand
    {
        Action<object> _execute;
        private Func<bool> _canExecute;

        public RelayCommand(Action<object> executeAction, Func<bool> canExecute = null) { 
            _execute = executeAction;
            _canExecute = canExecute;
        }

        public bool CanExecute(object? parameter)
        {
            if (_canExecute != null)
            {
                return _canExecute();
            }

            return true;
        }

        public void Execute(object? parameter)
        {
            if (_execute != null)
            {
                _execute(parameter);
            }
        }

        public event EventHandler CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;
            remove => CommandManager.RequerySuggested -= value;
        }

    }
}
